import boto3
import json
import base64
from io import BytesIO
import streamlit as st
import os

# Set AWS credentials and region
os.environ["AWS_ACCESS_KEY_ID"] = "AKIAZWWIRYGWVQUDR2NB"
os.environ["AWS_SECRET_ACCESS_KEY"] = "5YBLRbkkPmBTSsmx47lRoe7R+C2/uvWcPygi25AV"
os.environ["AWS_REGION"] = "your_region"

# Function to convert bytes to BytesIO
def get_bytesio_from_bytes(image_bytes):
    return BytesIO(image_bytes)

# Function to convert bytes to base64 string
def get_base64_from_bytes(image_bytes):
    resized_io = get_bytesio_from_bytes(image_bytes)
    return base64.b64encode(resized_io.getvalue()).decode("utf-8")

# Function to read bytes from a file
def get_bytes_from_file(file_path):
    with open(file_path, "rb") as image_file:
        return image_file.read()

# Function to create the request body for image understanding
def get_image_understanding_request_body(prompt, image_bytes=None, mask_prompt=None, negative_prompt=None):
    input_image_base64 = get_base64_from_bytes(image_bytes)
    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 2000,
        "temperature": 0,
        "messages": [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": "image/jpeg",
                            "data": input_image_base64,
                        },
                    },
                    {
                        "type": "text",
                        "text": prompt
                    }
                ],
            }
        ],
    }
    return json.dumps(body)

# Function to get response from the model
def get_response_from_model(prompt_content, image_bytes, mask_prompt=None):
    session = boto3.Session()
    bedrock = session.client(service_name='bedrock-runtime')
    body = get_image_understanding_request_body(prompt_content, image_bytes, mask_prompt=mask_prompt)
    response = bedrock.invoke_model(
        body=body,
        modelId="anthropic.claude-3-sonnet-20240229-v1:0",
        contentType="application/json",
        accept="application/json"
    )
    response_body = json.loads(response.get('body').read())
    return response_body['content'][0]['text']

# Streamlit app configuration
st.set_page_config(layout="wide", page_title="Image Understanding")
st.title("Image Understanding")

# Layout with three columns
col1, col2, col3 = st.columns(3)

# Prompt options
prompt_options_dict = {
    "Image caption": "Please provide a brief caption for this image.",
    "Detailed description": "Please provide a thoroughly detailed description of this image.",
    "Image classification": "Please categorize this image into one of the following categories: People, Food, Other. Only return the category name.",
    "Object recognition": "Please create a comma-separated list of the items found in this image. Only return the list of items.",
    "Subject identification": "Please name the primary object in the image. Only return the name of the object in <object> tags.",
    "Writing a story": "Please write a fictional short story based on this image.",
    "Answering questions": "What emotion are the people in this image displaying?",
    "Transcribing text": "Please transcribe any text found in this image.",
    "Translating text": "Please translate the text in this image to French.",
    "Other": "",
}

prompt_options = list(prompt_options_dict)

# Column 1: Image upload
with col1:
    st.subheader("Select an Image")
    uploaded_file = st.file_uploader("Select an image", type=['png', 'jpg'])
    if uploaded_file:
        uploaded_image_preview = get_bytesio_from_bytes(uploaded_file.getvalue())
        st.image(uploaded_image_preview)

# Column 2: Prompt selection
with col2:
    st.subheader("Prompt")
    prompt_selection = st.radio("Prompt example:", prompt_options)
    prompt_example = prompt_options_dict[prompt_selection]
    prompt_text = st.text_area("Prompt", value=prompt_example)

# Column 3: Display response
with col3:
    st.subheader("Response")
    if uploaded_file and prompt_text:
        image_bytes = uploaded_file.getvalue()
        response = get_response_from_model(prompt_text, image_bytes)
        st.write(response)
