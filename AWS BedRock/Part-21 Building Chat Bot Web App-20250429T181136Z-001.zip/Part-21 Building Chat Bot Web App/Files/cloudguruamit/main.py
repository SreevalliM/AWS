import time
import os
import boto3
import streamlit as st

from langchain.chains import ConversationChain
from langchain.llms.bedrock import Bedrock
from langchain.memory import ConversationBufferMemory

# Setting AWS environment variables
os.environ["AWS_ACCESS_KEY_ID"] = "<ENTER_ACCESS_KEY>"
os.environ["AWS_SECRET_ACCESS_KEY"] = "<ENTER_SECRET_ACCESS_KEY>"
os.environ["AWS_REGION"] = "us-east-1"

st.set_page_config(layout="wide", page_title="CloudGuruAmit Chat Bot", page_icon=":robot_face:")

# Custom CSS to enhance the appearance
custom_css = """
<style>
/* Hide Streamlit elements */
div[data-testid="stToolbar"], div[data-testid="stDecoration"], div[data-testid="stStatusWidget"], #MainMenu, header, footer {
    visibility: hidden;
    height: 0%;
    position: fixed;
}

/* Main container styling */
.reportview-container {
    margin-top: -2em;
    background-color: #f0f2f6;
    padding: 2em;
    border-radius: 10px;
}

/* Chat message styling */
.stChatMessage {
    border: 1px solid #e6e6e6;
    border-radius: 10px;
    padding: 1em;
    margin-bottom: 1em;
    background-color: #ffffff;
}

/* User message styling */
.stChatMessage.user {
    background-color: #e6f7ff;
}

/* Assistant message styling */
.stChatMessage.assistant {
    background-color: #f9f9f9;
}

/* Input box styling */
.stTextInput {
    border: 1px solid #e6e6e6;
    border-radius: 10px;
    padding: 1em;
    margin-top: 1em;
}
</style>
"""
st.markdown(custom_css, unsafe_allow_html=True)

st.title("🤖 CloudGuruAmit Chat Bot")

# Setup bedrock
bedrock_runtime = boto3.client(
    service_name="bedrock-runtime",
    region_name="us-east-1",
)

@st.cache_resource
def load_llm():
    llm = Bedrock(client=bedrock_runtime, model_id="anthropic.claude-v2")
    llm.model_kwargs = {"temperature": 0.7, "max_tokens_to_sample": 2048}
    model = ConversationChain(llm=llm, verbose=True, memory=ConversationBufferMemory())
    return model

model = load_llm()

if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

if prompt := st.chat_input("Message CloudGuruAmit Chat Bot"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        message_placeholder = st.empty()
        full_response = ""

        result = model.predict(input=prompt)

        # Simulate stream of response with milliseconds delay
        for chunk in result.split(' '):
            full_response += chunk + ' '
            if chunk.endswith('\n'):
                full_response += ' '
            time.sleep(0.05)
            message_placeholder.markdown(full_response + "▌")

        message_placeholder.markdown(full_response)

    st.session_state.messages.append({"role": "assistant", "content": full_response})
